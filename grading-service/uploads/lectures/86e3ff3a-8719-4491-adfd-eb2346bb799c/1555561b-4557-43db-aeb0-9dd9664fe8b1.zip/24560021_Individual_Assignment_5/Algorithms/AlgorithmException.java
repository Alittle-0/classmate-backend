package Algorithms;// filepath: d:\chatApplication\Assignment\src\Algorithms\Algorithms.AlgorithmException.java

public class AlgorithmException extends RuntimeException {

    public AlgorithmException() {
        super();
    }

    public AlgorithmException(String message) {
        super(message);
    }

    public AlgorithmException(String message, Throwable cause) {
        super(message, cause);
    }
}

