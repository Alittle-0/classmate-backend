package Algorithms;

import java.util.ArrayList;

public class InsertionSort {

    public void sortByInsertionSort(ArrayList<Double> array) {
        if (array == null || array.isEmpty()) {
            throw new AlgorithmException("Array must not be null or empty");
        }
        for (int j = 1; j < array.size(); j++) {
            int i = 0;
            while (array.get(j) > array.get(i))
                i += 1;
            double m = array.get(j);
            for (int k = 0; k < j-i; k++)
                array.set(j-k, array.get(j-k-1));
            array.set(i, m);
        }
    }

    public ArrayList<Double> sortByInsertionSort() {
        ArrayList<Double> array = new ArrayList<>();
        array.add(6.0);
        array.add(9.0);
        array.add(7.0);
        array.add(10.0);
        array.add(7.0);
        sortByInsertionSort(array);
        return array;
    }

    public static void main(String[] args) {
        InsertionSort insertionSort = new InsertionSort();
        ArrayList<Double> array = insertionSort.sortByInsertionSort();
        for(double i : array) {
            System.out.print(i + " ");
        }
        System.out.println();
    }
}
