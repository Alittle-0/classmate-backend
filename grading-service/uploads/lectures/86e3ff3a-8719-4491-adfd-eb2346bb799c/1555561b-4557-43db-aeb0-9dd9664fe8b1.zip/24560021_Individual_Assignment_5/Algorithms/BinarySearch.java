package Algorithms;

import java.util.ArrayList;

public class BinarySearch {

    public int searchByBinarySearch(ArrayList<Integer> array, int x) {
        if (array == null || array.isEmpty()) {
            throw new AlgorithmException("Array must not be null or empty");
        }
        int i = 0;
        int j = array.size() - 1;
        while (i < j) {
            int m = (i + j) / 2;
            if (array.get(m) < x)
                i = m + 1;
            else
                j = m;
        }
        if (array.get(i) == x)
            return i;
        return -1;
    }

    public int searchByBinarySearch() {
        ArrayList<Integer> array = new ArrayList<>();
        array.add(6);
        array.add(7);
        array.add(8);
        array.add(9);
        array.add(10);
        return searchByBinarySearch(array, 1);
    }

    public static void main(String[] args) {
        BinarySearch binarySearch = new BinarySearch();
        int result = binarySearch.searchByBinarySearch();
        if (result == -1)
            System.out.println("Element not found!");
        else  System.out.println("Element found at index: " + result);
    }

}
