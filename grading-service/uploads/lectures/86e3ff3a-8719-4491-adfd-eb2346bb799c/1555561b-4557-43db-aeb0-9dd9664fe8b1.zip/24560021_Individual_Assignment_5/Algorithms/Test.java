package Algorithms;

import java.util.ArrayList;
import java.util.Scanner;

public class Test {

    public ArrayList<Integer> initIntArray(Scanner sc) {
        ArrayList<Integer> array = new ArrayList<>();
        System.out.println("Enter the number of elements in the array: ");
        int n = sc.nextInt();
        if (n <= 0) {
            throw new AlgorithmException("Array size must be greater than 0");
        }
        for (int i = 0; i < n; i++) {
            System.out.println("Enter the element " + (i + 1) + ": ");
            int element = sc.nextInt();
            array.add(element);
        }
        return array;
    }

    public ArrayList<Double> initDoubleArray(Scanner sc) {
        ArrayList<Double> array = new ArrayList<>();
        System.out.print("Enter the number of elements in the array: ");
        int n = sc.nextInt();
        if (n < 2) {
            throw new AlgorithmException("Array size must be greater or equal to 2");
        }
        System.out.println();
        for (int i = 0; i < n; i++) {
            System.out.print("Enter the element " + (i + 1) + ": ");
            double element = sc.nextDouble();
            System.out.println();
            array.add(element);
        }
        return array;
    }

    public int valueToSearch(Scanner sc) {
        System.out.print("Enter value to search: ");
        return sc.nextInt();
    }

    public static void main(String[] args) {
        //Test menu
        try {
            Scanner sc = new Scanner(System.in);
            Test test = new Test();
            FindMax findMax = new FindMax();
            LinearSearch linearSearch = new LinearSearch();
            BinarySearch binarySearch = new BinarySearch();
            BubbleSort bubbleSort = new BubbleSort();
            InsertionSort insertionSort = new InsertionSort();

            int choice = 0;
            do {
                System.out.println("------Menu------");
                System.out.println("1. Find max element");
                System.out.println("2. Find element by Linear Search");
                System.out.println("3. Find element by Binary Search");
                System.out.println("4. Sort array by Bubble Sort");
                System.out.println("5. Sort array by Insertion Sort");
                System.out.println("0. Exit");

                System.out.print("Enter your choice (0-5): ");
                choice = sc.nextInt();
                System.out.println();
                switch (choice) {
                    case 1:
                        ArrayList<Integer> array1 = test.initIntArray(sc);
                        System.out.println("Max element: " + findMax.findMaxElement(array1));
                        break;
                    case 2:
                        ArrayList<Integer> array2 = test.initIntArray(sc);
                        int index = linearSearch.searchByLinearSearch(array2, test.valueToSearch(sc));
                        System.out.println(index >= 0 ? "Found at index " + index : "Not found");
                        break;
                    case 3:
                        ArrayList<Integer> array3 = test.initIntArray(sc);
                        bubbleSort.sort(array3);
                        int binaryIndex = binarySearch.searchByBinarySearch(array3, test.valueToSearch(sc));
                        System.out.println(binaryIndex >= 0 ? "Found at index " + binaryIndex : "Not found");
                        break;
                    case 4:
                        ArrayList<Double> array4 = test.initDoubleArray(sc);
                        bubbleSort.sortByBubbleSort(array4);
                        System.out.print("Sorted by Bubble Sort: " + array4);
                        break;
                    case 5:
                        ArrayList<Double> array5 = test.initDoubleArray(sc);
                        insertionSort.sortByInsertionSort(array5);
                        System.out.println("Sorted by Insertion Sort: " + array5);
                        break;
                    case 0:
                        System.out.println("Exiting...");
                        break;
                    default:
                        System.out.println("Invalid choice");
                }
                System.out.println();
            } while (choice != 0);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
