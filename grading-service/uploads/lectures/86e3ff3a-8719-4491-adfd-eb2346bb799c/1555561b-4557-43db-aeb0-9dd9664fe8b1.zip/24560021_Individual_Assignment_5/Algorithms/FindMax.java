package Algorithms;

import java.util.ArrayList;

public class FindMax {
    public int findMaxElement(ArrayList<Integer> array) {
        if (array == null || array.isEmpty()) {
            throw new AlgorithmException("Array must not be null or empty");
        }
        int max = array.get(0);
        for (int i = 1; i < array.size(); i++) {
            if (max < array.get(i)) {
                max = array.get(i);
            }
        }
        return max;
    }

    public int findMaxElement() {
        ArrayList<Integer> array = new ArrayList<>();
        array.add(1);
        array.add(2);
        array.add(3);
        array.add(4);
        array.add(5);
        return findMaxElement(array);
    }

    public static void main(String[] args) {
        FindMax findMax = new FindMax();
        System.out.println("Max element: " + findMax.findMaxElement());
    }
}
