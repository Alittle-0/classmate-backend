package Algorithms;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class LinearSearch {
    public int searchByLinearSearch(ArrayList<Integer> array, int x) {
        if (array == null || array.isEmpty()) {
            throw new AlgorithmException("Array must not be null or empty");
        }

        Set<Integer> seen = new HashSet<>(array);
        if (seen.size() < array.size()) {
            throw new AlgorithmException("In Linear Search algorithm, array must not contain duplicate elements");
        }

        int i = 0;
        while (i < array.size() && x != array.get(i))
            i += 1;
        if (i < array.size())
            return i;
        return -1;
    }

    public int searchByLinearSearch() {
        ArrayList<Integer> array = new ArrayList<>();
        array.add(1);
        array.add(2);
        array.add(3);
        array.add(4);
        array.add(5);
        return searchByLinearSearch(array, 3);
    }

    public static void main(String[] args) {
        LinearSearch linearSearch = new LinearSearch();
        int result = linearSearch.searchByLinearSearch();
        if (result == -1)
            System.out.println("Element not found!");
        else  System.out.println("Element found at index: " + result);
    }
}
