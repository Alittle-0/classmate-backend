package Algorithms;

import java.util.ArrayList;

public class BubbleSort {

    public void sortByBubbleSort(ArrayList<Double> array) {
        if (array == null || array.isEmpty()) {
            throw new AlgorithmException("Array must not be null or empty");
        }
        for (int i = 0; i < array.size() - 1; i++) {
            for (int j = 0; j < array.size() - i - 1; j++) {
                if (array.get(j) > array.get(j + 1)) {
                    double temp = array.get(j);
                    array.set(j, array.get(j + 1));
                    array.set(j + 1, temp);
                }
            }
        }
    }

    public void sort(ArrayList<Integer> array) {
        if (array == null || array.isEmpty()) {
            throw new AlgorithmException("Array must not be null or empty");
        }
        for (int i = 0; i < array.size() - 1; i++) {
            for (int j = 0; j < array.size() - i -1; j++) {
                if (array.get(j) > array.get(j + 1)) {
                    int temp = array.get(j);
                    array.set(j, array.get(j + 1));
                    array.set(j + 1, temp);
                }
            }
        }
    }

    public ArrayList<Double> sortByBubbleSort() {
        ArrayList<Double> array = new ArrayList<>();
        array.add(1.0);
        array.add(4.0);
        array.add(2.0);
        array.add(5.0);
        array.add(2.0);
        sortByBubbleSort(array);
        return array;
    }

    public static void main(String[] args) {
        BubbleSort bubbleSort = new BubbleSort();
        ArrayList<Double> array = bubbleSort.sortByBubbleSort();
        for(double i : array) {
            System.out.print(i + " ");
        }
        System.out.println();
    }
}
