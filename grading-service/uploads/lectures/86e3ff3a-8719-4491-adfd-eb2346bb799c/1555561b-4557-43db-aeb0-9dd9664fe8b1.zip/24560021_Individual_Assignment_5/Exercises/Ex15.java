package Exercises;

import java.util.ArrayList;

public class Ex15 {

    public void insertIntoSortedArray(ArrayList<Integer> list, int element) {
        if (list == null || list.isEmpty()) {
            throw new IllegalArgumentException("Array must not be null or empty");
        }
        for (int i = 0; i < list.size()-1; i++) {
            if (list.get(i) > list.get(i+1)) {
                throw new IllegalArgumentException("List must be sorted in increasing order");
            }
        }
        int left = 0, right = list.size() - 1;
        while (left <= right) {
            int mid = (left + right) / 2;
            if (list.get(mid) < element) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        list.add(0);
        for (int j = list.size() - 2; j >= left; j--) {
            list.set(j + 1, list.get(j));
        }
        list.set(left, element);
    }

    public void insertIntoSortedArray() {
        ArrayList<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(3);
        list.add(2);
        list.add(4);
        list.add(5);
        insertIntoSortedArray(list, 3);
        for(int i : list) {
            System.out.print(i + " ");
        }
    }

    public static void main(String[] args) {
        Ex15 ex15 = new Ex15();
        ex15.insertIntoSortedArray();
    }

}
