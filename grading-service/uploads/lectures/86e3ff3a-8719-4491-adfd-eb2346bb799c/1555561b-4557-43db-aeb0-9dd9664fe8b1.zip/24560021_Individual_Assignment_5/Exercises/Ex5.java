package Exercises;

import java.util.ArrayList;

public class Ex5 {

    public ArrayList<Integer> findDuplicateValue(ArrayList<Integer> list ) {
        if (list == null || list.isEmpty()) {
            throw new IllegalArgumentException("List must not be null or empty");
        }
        ArrayList<Integer> duplicates = new ArrayList<>();
        for (int i = 0; i < list.size()-1; i++) {
            if (list.get(i).equals(list.get(i+1)) && !duplicates.contains(list.get(i))) {
                duplicates.add(list.get(i));
                i += 1;
            }
        }
        return duplicates;
    }

    public ArrayList<Integer> findDuplicateValue() {
        ArrayList<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(2);
        list.add(2);
        list.add(3);
        list.add(5);
        list.add(5);
        list.add(5);
        list.add(5);
        list.add(7);
        list.add(9);
        return findDuplicateValue(list);
    }

    public static void main(String[] args) {
        Ex5 ex5 = new Ex5();
        System.out.println("Duplicate values in the given list: " + ex5.findDuplicateValue());
    }

}
