package Exercises;

import java.util.ArrayList;

public class Ex6 {

    public ArrayList<Integer> findNegaInt(ArrayList<Integer> list) {
        if (list == null || list.isEmpty()) {
            throw new IllegalArgumentException("List must not be null or empty");
        }
        ArrayList<Integer> negaList = new ArrayList<>();
        for (int i : list) {
            if (i < 0) {
                negaList.add(i);
            }
        }
        return negaList;
    }

    public ArrayList<Integer> findNegaInt() {
        ArrayList<Integer> list = new ArrayList<>();
        list.add(-1);
        list.add(2);
        list.add(-3);
        list.add(4);
        list.add(-5);
        return findNegaInt(list);
    }

    public static void main(String[] args) {
        Ex6 ex6 = new Ex6();
        System.out.println("Negative integers in the given list: " + ex6.findNegaInt());
    }

}
