package Exercises;

import java.util.ArrayList;

public class Ex8 {

    public int findLargestEvenInt(ArrayList<Integer> list) {
        if (list == null || list.isEmpty()) {
            throw new IllegalArgumentException("List must not be null or empty");
        }
        int evenMax = 0;
        for (int i : list) {
            if (i % 2 == 0 && i > evenMax) {
                evenMax = i;
            }
        }
        return evenMax;
    }

    public int findLargestEvenInt() {
        ArrayList<Integer> list = new ArrayList<>();
        list.add(2);
        list.add(1);
        list.add(3);
        list.add(7);
        list.add(4);
        return findLargestEvenInt(list);
    }

    public static void main(String[] args) {
        Ex8 ex8 = new Ex8();
        System.out.println("Largest even integer in the given list: " + ex8.findLargestEvenInt());
    }

}
