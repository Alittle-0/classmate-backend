package Exercises;

import java.util.ArrayList;

public class Ex7 {

    public int findLastEvenInt(ArrayList<Integer> list) {
        if (list == null || list.isEmpty()) {
            throw new IllegalArgumentException("List must not be null or empty");
        }
        for (int i = list.size()-1; i >= 0; i--) {
            if (list.get(i) % 2 == 0) {
                return list.get(i);
            }
        }
        return 0;
    }

    public int findLastEvenInt() {
        ArrayList<Integer> list = new ArrayList<>();
        list.add(2);
        list.add(1);
        list.add(3);
        list.add(7);
        list.add(5);
        return findLastEvenInt(list);
    }

    public static void main(String[] args) {
        Ex7 ex7 = new Ex7();
        System.out.println("Last even integer in the given list: " + ex7.findLastEvenInt());
    }
}
