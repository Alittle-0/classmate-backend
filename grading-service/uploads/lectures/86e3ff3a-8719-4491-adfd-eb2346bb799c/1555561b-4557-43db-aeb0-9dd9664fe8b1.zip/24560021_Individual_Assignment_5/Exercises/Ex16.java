package Exercises;

import java.util.ArrayList;

public class Ex16 {

    public int findMinElement(ArrayList<Integer> list) {
        if (list == null || list.isEmpty()) {
            throw new IllegalArgumentException("List must not be null or empty");
        }
        for (int i : list) {
            if (i < 0) {
                throw new IllegalArgumentException("List must not contain negative numbers");
            }
        }
        if (list.size() == 1) {
            return list.getFirst();
        }
        int min = list.getFirst();
        for (int i : list) {
            if (i < min) {
                min = i;
            }
        }
        return min;
    }

    public int findMinElement() {
        ArrayList<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(5);
        return findMinElement(list);
    }

    public static void main(String[] args) {
        Ex16 ex16 = new Ex16();
        System.out.println("Minimum element in the given list: " + ex16.findMinElement());
    }

}
