package Exercises;

import java.util.ArrayList;

public class Ex4 {

    public int findMaxDiff(ArrayList<Integer> list) {
        if (list == null || list.isEmpty()) {
            throw new IllegalArgumentException("List must not be null or empty");
        }
        int maxDiff = Integer.MIN_VALUE;
        for (int i = 0; i < list.size() - 1; i++) {
            int diff = list.get(i+1) - list.get(i);
            if (diff > maxDiff)
                    maxDiff = diff;
        }
        return maxDiff;
    }

    public int findMaxDiff() {
        ArrayList<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(7);
        return findMaxDiff(list);
    }

    public static void main(String[] args) {
        Ex4 ex4 = new Ex4();
        System.out.println("Max difference between adjacent elements in the given list: " + ex4.findMaxDiff());
    }

}
