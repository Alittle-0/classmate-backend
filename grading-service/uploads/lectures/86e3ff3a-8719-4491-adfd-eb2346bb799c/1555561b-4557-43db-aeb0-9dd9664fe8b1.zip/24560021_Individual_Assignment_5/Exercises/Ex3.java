package Exercises;


import java.util.ArrayList;

public class Ex3 {

    public int sumOfIntegerList(ArrayList<Integer> list) {
        if (list == null || list.isEmpty()) {
            throw new IllegalArgumentException("List must not be null or empty");
        }
        int sum = 0;
        for (int i : list) {
            sum += i;
        }
        return sum;
    }

    public int sumOfIntegerList() {
        ArrayList<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(5);
        return sumOfIntegerList(list);
    }

    public static void main(String[] args) {
        Ex3 ex3 = new Ex3();
        System.out.println("Sum of all integers in the given list: " + ex3.sumOfIntegerList());
    }

}
